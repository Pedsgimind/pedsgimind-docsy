(Full parent-friendly Markdown post — clean .md, ready for PedsGIMind; FAQs are autism + gut/feeding specific, not generic)
# 🧒🧩 Autism (Autism Spectrum Disorder) and the Gut: Feeding, Constipation, and Practical Supports (Parent-Friendly Guide)

> ✅ **Autism Spectrum Disorder (ASD)** affects how a child communicates, interacts, and experiences the world.  
> Many autistic children also have **gut and feeding challenges**—especially **constipation, abdominal pain, reflux, selective eating, and sensory-based food aversions**.  
> This guide focuses on practical, parent-friendly steps for day-to-day health, nutrition, and when to seek help.

---

## 1) 🧾 Quick “At-a-glance” box (top of page)

> ✅ **Condition name + common names:**  
> **Autism (Autism Spectrum Disorder)**  
> **Common related concerns:** selective eating, sensory feeding difficulties, constipation, stool withholding
>
> **2–3 line plain-language summary:**  
> Autism is a neurodevelopmental difference. Many autistic children have gut symptoms and feeding challenges due to sensory sensitivities, routines, anxiety, and communication differences. Treating constipation and supporting nutrition can improve comfort, sleep, and behavior.
>
> **Who it affects (typical ages):**  
> Signs often appear in toddler years; diagnosis can occur in preschool years or later.
>
> ✅ **What parents should do today:**  
> - Treat constipation early and consistently (very common)  
> - Track pain signals and stool patterns (behavior may be the clue)  
> - Keep meals predictable; offer safe foods plus tiny “learning” steps  
> - Ask for dietitian/feeding therapy support if diet is very restricted
>
> ⚠️ **Red flags needing urgent/ER care:**  
> - Severe belly pain with vomiting or swollen belly  
> - No stool for many days + pain/distension  
> - Blood in stool with illness or significant pain  
> - Dehydration (very low urine, lethargy)
>
> 🟡 **When to see the clinic soon:**  
> - Chronic constipation or stool accidents  
> - Very limited diet (risk of nutrient deficiency)  
> - Weight loss, poor growth, fatigue  
> - New feeding refusal after choking or illness  
> - Suspected reflux with pain or sleep disruption

---

## 2) 🧠 What it is (plain language)

Autism is a **different way the brain develops and processes information**.  
It can affect:
- communication (speech or non-verbal communication)
- social interaction
- sensory processing (sound, texture, taste, smell)
- routines and flexibility

Autism is **not caused by parenting**, and it is **not contagious**.

### What part of the body is involved? (small diagram required)

<!-- AI IMAGE PROMPT: Parent-friendly diagram showing “brain ↔ gut connection” with calm icons: brain, stomach, colon. Include arrows labeled “sensory sensitivity,” “anxiety/stress,” “constipation,” “pain signals.” -->
![Diagram showing brain-gut connection in autism (sensory sensitivity, stress, constipation, pain signals)](/images/autism-gut-connection-placeholder-1.png)

### Common myths vs facts
- **Myth:** “Autism is caused by vaccines.”  
  **Fact:** No. Autism is a neurodevelopmental condition; vaccines do not cause autism.
- **Myth:** “Autistic kids don’t feel pain the same way.”  
  **Fact:** Many feel pain strongly but may show it differently.
- **Myth:** “Constipation is just a diet issue.”  
  **Fact:** It can also be behavioral (withholding), sensory, anxiety-related, and needs a full plan.

---

## 3) 🧩 Why gut and feeding issues happen in autism (causes & triggers)

### Common reasons
- sensory sensitivity to textures, smells, temperatures
- preference for sameness/routines
- anxiety around new foods or mealtimes
- motor planning and oral-motor coordination differences (some children)
- communication differences → pain may show as behavior
- constipation from limited diet + withholding + low fluid intake

### Less common but important contributors
- reflux (heartburn) causing food refusal
- food allergy/intolerance (selected cases)
- inflammatory bowel disease (rare; consider if red flags)
- celiac disease (selected cases, depending on symptoms/family history)

### Triggers that worsen symptoms
- sudden food changes
- pressure to eat
- rushing meals
- school stress or transitions
- constipation left untreated

---

## 4) 👀 What parents might notice (symptoms)

### Typical GI/feeding patterns
- constipation or stool withholding
- large stools, painful stools, fissures
- stool accidents (overflow soiling)
- bloating or gas
- selective eating (limited food “safe list”)
- gagging with textures
- reflux signs (chest discomfort, arching in young kids, throat clearing)

### How pain can look (behavioral signals)
- irritability, aggression, self-injury
- sudden sleep disruption
- new refusal to sit at table
- pressing belly against objects
- walking on toes more, crouching, or posturing

### Symptoms by age group
- **Toddlers:** selective eating, constipation, sleep issues
- **School-age:** stool accidents, abdominal pain, anxiety-related feeding issues
- **Teens:** restricted diets, reflux, functional pain, stress-related symptoms

### What’s normal vs what’s not normal
🟢 Common (but should still be supported):
- selective eating with stable growth and adequate variety over time

⚠️ Not normal:
- weight loss or growth faltering
- blood in stool with diarrhea
- persistent vomiting
- severe constipation with distension

### Trackers
- stool diary (frequency, pain, accidents)
- food list (safe foods, new exposures)
- behavior and sleep notes
- hydration and urine output

---

## 5) 🏠 Home care and what helps (step-by-step)

> ✅ In autism, GI care works best when it’s **predictable, low-pressure, and consistent**.

### First 24–48 hours: “Comfort & Basics” plan
> ✅ **Do this now:**
- Hydration: add water opportunities through routine (same cup, same place)
- Set a regular toilet sit time (after meals, 5 minutes, no pressure)
- Treat constipation early (ask your clinician for a stool plan)
- Keep meals structured: predictable times, calm setting

### Feeding support basics
- Start with “safe foods” to protect calories
- Add **tiny exposures** (“learning bites”) without pressure:
  - smell → touch → lick → bite → chew → swallow
- Keep new foods **near** safe foods, not replacing them

### Constipation plan basics (core concept)
- goal is **soft, easy stools**
- treat stool withholding with:
  - softening stool
  - predictable toilet routine
  - positive reinforcement (not punishment)

### What usually makes things worse
- pressuring, bargaining, or forcing bites
- sudden removal of safe foods
- ignoring constipation
- unpredictable routines

---

## 6) ⛔ What NOT to do (common mistakes)

- Don’t use punishment for stool accidents (often overflow from constipation).
- Don’t remove entire food groups in an already restricted eater without supervision.
- Don’t start multiple supplements/diets without guidance (risk of deficiency).
- Don’t assume “behavior problem” when pain could be the cause.

---

## 7) 🚦 When to worry: triage guidance

### 🔴 Call 911 / Emergency now
- severe belly pain + vomiting + swollen belly
- signs of obstruction (no stool/gas + severe pain)
- severe dehydration with lethargy

### 🟠 Same-day urgent visit
- persistent vomiting
- severe constipation with pain/distension
- blood in stool with illness or significant pain

### 🟡 Book a routine appointment
- chronic constipation or stool accidents
- very restricted diet (risk of iron, B12, vitamin D, zinc deficiencies)
- reflux symptoms impacting sleep or eating
- recurrent abdominal pain affecting school

### 🟢 Watch at home
- mild selective eating with stable growth and expanding variety slowly

---

## 8) 🩺 How doctors assess autism + gut/feeding issues

### What the clinician will ask
- stool frequency, pain, accidents
- diet variety and fluid intake
- growth and energy
- behavior/sleep changes related to meals or stooling
- reflux symptoms
- any red flags (weight loss, blood, persistent vomiting)

### Physical exam basics
- growth measurements
- belly exam for stool burden
- hydration
- skin signs of nutritional deficiency (selected cases)

### Possible tests (and why)
- iron studies if fatigue/pallor or restricted diet
- vitamin D if limited diet
- celiac screening if symptoms suggest it
- stool tests if chronic diarrhea or blood

### What tests are usually not needed
- broad testing if growth is normal and constipation management improves symptoms

---

## 9) 🧰 Treatment options

### First-line (most common wins)
- constipation treatment plan (softeners + routine + behavior supports)
- dietitian support for restricted diet
- feeding therapy (OT/SLP with feeding expertise)
- reflux treatment if suspected and impacting feeding/sleep

### If not improving
- GI referral for persistent constipation, pain, reflux, or growth issues
- psychology support for anxiety/ARFID patterns (if present)

### Severe cases
- hospital care for dehydration/impaction/obstruction concerns
- structured intensive feeding programs when needed

---

## 10) ⏳ Expected course & prognosis

- constipation often improves over weeks with consistent plan
- selective eating improvement is usually **slow and steady**
- feeding therapy success is often measured in:
  - reduced stress
  - increased tolerance
  - gradual variety expansion

### Return to school/daycare
- create a written toileting plan
- allow water access
- ensure predictable meal/snack schedule

---

## 11) ⚠️ Complications (brief but clear)

- chronic constipation → fissures, stool accidents, pain cycles
- nutritional deficiencies from very restricted diets
- dehydration
- sleep disruption affecting behavior and learning

---

## 12) 🛡️ Prevention and reducing future episodes

- treat constipation early
- consistent routines for meals and toileting
- gradual food exposure strategy
- early referral for feeding therapy when diet is narrowing

---

## 13) 🌟 Special situations

### Infants
Feeding difficulties may involve reflux and sensory responses; early support helps.

### Teens
Watch for restrictive eating patterns and anxiety; address autonomy and privacy.

### Kids with chronic conditions
Coordinate meds and nutrition; constipation can worsen with some medications.

### Neurodevelopmental differences/autism (practical adaptations)
- visual schedules for toileting and meals
- first/then language (“first sit, then preferred activity”)
- sensory supports (foot stool, quiet bathroom, preferred wipes)

### Travel considerations
Bring safe foods, stool plan supplies, and hydration routines.

### School/daycare notes
- toileting schedule
- allowed bathroom breaks
- stool accident plan (supportive, not punitive)

---

## 14) 📅 Follow-up plan

- follow-up with pediatrician/GI if constipation doesn’t improve
- dietitian follow-up if restricted diet persists
- earlier follow-up if:
  - weight changes
  - blood in stool
  - severe pain/vomiting

---

## 15) ❓ Parent FAQs (Autism + GI/Feeding-Specific)

### “Why does constipation cause behavior changes?”
Constipation can be painful. Many autistic children show pain through behavior, sleep changes, or refusal rather than saying “my tummy hurts.”

### “Is picky eating the same as a feeding disorder?”
Not always. It becomes concerning when the diet is very limited, growth is affected, or mealtimes are highly stressful—then feeding therapy can help.

### “Should we try gluten-free/casein-free diets?”
Some families try them, but they’re not right for every child and can reduce nutrition. Discuss with your clinician/dietitian first.

### “What if my child refuses to sit on the toilet?”
Start small: short sit times, predictable routine, foot support, and positive reinforcement—avoid pressure or punishment.

### “How do I know if reflux is causing food refusal?”
Clues: discomfort after eating, arching, throat clearing, chronic cough, or sleep disruption. Your clinician can guide evaluation and treatment.

---

## 16) 🧾 Printable tools (high-value add-ons)

---

## 🧾 Printable: Constipation & Toileting Routine Plan
- Sit after meals: ____ minutes  
- Foot stool used: yes/no  
- Reward after sitting: __________  
- Stool goal: soft, easy, daily or every other day

---

## 🧾 Printable: “Pain Signals” Checklist
When my child is uncomfortable, they may:
- [ ] get irritable  
- [ ] stop sleeping well  
- [ ] press belly  
- [ ] refuse meals  
- [ ] have stool accidents  

---

## 🧾 Printable: Food Expansion Ladder
Safe food → same brand → similar shape → similar color → small taste → new food

---

## 17) 📚 Credible sources + last updated date

**Trusted references:**
- Children’s hospital autism + feeding/constipation resources  
- National autism organizations’ medical guidance  
- Pediatric gastroenterology society constipation and feeding resources  

**Last reviewed/updated on:** 2025-12-31  
*Approaches vary—follow your clinician and therapy team’s advice.*

---

## 18) 🧡 Safety disclaimer

This guide supports—not replaces—medical advice. Seek urgent care for severe abdominal pain, vomiting, dehydration, or bowel obstruction concerns.

---

> ---
> **This guide was fully developed & reviewed by Dr. Mohammad Hussein, MD, FRCPC ROYAL COLLEGE–CERTIFIED PEDIATRICIAN & PEDIATRIC GASTROENTEROLOGIST Board-certified pediatrician and pediatric gastroenterologist (Royal College of Physicians and Surgeons of Canada) with expertise in inflammatory bowel disease, eosinophilic gastrointestinal disorders, motility and functional testing, and complex nutrition across diverse international practice settings. To book an online assessment Email Dr. Hussein’s Assistant Elizabeth Gray at: Elizabeth.Gray@pedsgimind.ca In the email subject, please write: New Assessment Appointment with Dr. Hussein Important: This appointment is completely online as Dr. Hussein is currently working overseas. This service is not covered by OHIP**
> ---
